﻿using Microsoft.AspNetCore.Mvc;
using ProiectMaster.Models.DTOs.VM;
using ProiectMaster.Models.Interfaces;
using ProiectMaster.Services;
using System;
using System.Collections.Generic;

namespace ProiectMaster.Web.Controllers
{
    [Route("[Controller]")]
    public class ShoppingCart : Controller
    {
        private readonly IOrderService serviceOrder;
        private readonly IProductService productService;
        private readonly IOrdersProductService ordersProductService;

        public ShoppingCart(IOrderService serviceOrder, IProductService productService, IOrdersProductService ordersProductService)
        {
            this.serviceOrder = serviceOrder;
            this.productService = productService;
            this.ordersProductService = ordersProductService;
        }
        [HttpGet]
        public IActionResult Index()
        {
            var shopList = HttpContext.Session.Get<List<int>>(SessionHelper.ShoppingCart);

            if (shopList == null)
                shopList = new List<int>();

            var list = productService.GetAllProducts(shopList);
            return View(list);
        }

        [HttpPost]
        [Route("Remove/{id}")]
        public IActionResult Remove(int id)
        {
            var shopList = HttpContext.Session.Get<List<int>>(SessionHelper.ShoppingCart);

            if (shopList == null)
                return RedirectToAction("Index", "ShoppingCart", productService.GetAllProducts(new List<int>()));

            if (shopList.Contains(id))
                shopList.Remove(id);

            HttpContext.Session.Set(SessionHelper.ShoppingCart, shopList);

            return RedirectToAction("Index", "ShoppingCart", productService.GetAllProducts(shopList));
        }

        [HttpGet]
        [Route("NewOrder")]
        public IActionResult NewOrder()
        {
            //Cant create an order without products
            var shopList = HttpContext.Session.Get<List<int>>(SessionHelper.ShoppingCart);

            if (shopList == null)
                return RedirectToAction("Index", "ShoppingCart", productService.GetAllProducts(new List<int>()));

            var dto = new OrderVM();
            return View(dto);
        }

        [HttpPost]
        [Route("NewOrder")]
        public IActionResult NewOrder(OrderVM dto)
        {
            dto.OrderDate = DateTime.Now;

            //validate the model
            if (!ModelState.IsValid)
            {
                ModelState.AddModelError(string.Empty, "There were some errors in your form");
                return View(dto);
            }

            //Cant create an order without products - extra validation
            var shopList = HttpContext.Session.Get<List<int>>(SessionHelper.ShoppingCart);

            if (shopList == null)
                return RedirectToAction("Index", "ShoppingCart", productService.GetAllProducts(new List<int>()));


            //create the order
            var idOrder = serviceOrder.AddWithReturnId(dto);

            //create order products
            ordersProductService.AddOrderProducts(idOrder, shopList);

            //empty the shopping cart
            HttpContext.Session.Set(SessionHelper.ShoppingCart, new List<int>());


            return RedirectToAction("Index", "ShoppingCart", productService.GetAllProducts(new List<int>()));
        }
    }
}
