﻿using Microsoft.AspNetCore.Mvc;
using ProiectMaster.Models.Interfaces;
using ProiectMaster.Services;
using System.Linq;

namespace ProiectMaster.Web.Controllers
{
    [Controller]
    public class OrderController : Controller
    {
        private readonly IOrderService serviceOrder;
        private readonly IProductService productService;
        private readonly IOrdersProductService ordersProductService;

        public OrderController(IOrderService serviceOrder, IProductService productService, IOrdersProductService ordersProductService)
        {
            this.serviceOrder = serviceOrder;
            this.productService = productService;   
            this.ordersProductService = ordersProductService;
        }
        [HttpGet]
        public IActionResult Index()
        {
            var list = serviceOrder.GetAllOrders().OrderByDescending(x => x.Id);
            return View(list);
        }

        [HttpGet]
        [Route("Order/Details/{id}")]
        public IActionResult Details(int id)
        {
            var order = serviceOrder.GetOrder(id);
            var products = ordersProductService.GetAllProductsForOrder(id);
            return View(products);
        }
    }
}
