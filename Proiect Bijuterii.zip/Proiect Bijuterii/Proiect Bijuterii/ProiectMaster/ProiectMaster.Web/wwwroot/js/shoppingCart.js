﻿window.ShoppingCart = (function ($) {

    let removeFromCartUrl = "/Shopping/Cart/{0}";

    function _onRemoveFromCart() {

        let selectedId = getSelectedId();
        let url = stringFormat(removeFromCartUrl, selectedId);
        window.open(url, "_self");
    }

    return {
        onRemoveFromCart: _onRemoveFromCart
    }

}($));