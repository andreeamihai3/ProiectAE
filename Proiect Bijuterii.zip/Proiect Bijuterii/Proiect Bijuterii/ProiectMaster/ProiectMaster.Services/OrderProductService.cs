﻿using AutoMapper;
using AutoMapper.Configuration;
using MailKit.Net.Smtp;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using MimeKit;
using ProiectMaster.DataAccess.Interfaces;
using ProiectMaster.Models.DTOs.VM;
using ProiectMaster.Models.Entites;
using ProiectMaster.Models.Interfaces;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using IConfiguration = Microsoft.Extensions.Configuration.IConfiguration;

namespace ProiectMaster.Services
{
    public class OrderProductService : IOrdersProductService
    {
        private readonly IRepository<OrdersProduct, int> orderProductRep;
        private readonly IRepository<Order, int> orderRep;
        private readonly IRepository<Product, int> productRep;
        private readonly IConfiguration configuration;
        private readonly IMapper mapper;
        private readonly IHostingEnvironment hostingEnvironment;

        public OrderProductService(IRepository<OrdersProduct, int> orderProductRep, IMapper mapper, IConfiguration configuration, IRepository<Order, int> orderRep, IRepository<Product, int> productRep, IHostingEnvironment hostingEnvironment)
        {
            this.orderProductRep = orderProductRep;
            this.mapper = mapper;
            this.configuration = configuration;
            this.orderRep = orderRep;
            this.productRep = productRep;
            this.hostingEnvironment = hostingEnvironment;
        }

        public void AddOrderProduct(OrdersProductVM dto)
        {
            var entity = mapper.Map<OrdersProduct>(dto);
            orderProductRep.Add(entity);
        }

        public void AddOrderProducts(int idOrder, List<int> idsProducts)
        {
            foreach (var idProduct in idsProducts)
            {
                var entity = new OrdersProduct(idOrder, idProduct);
                InsertIntoOrderProductTableWithCompositePrimaryKey(entity);
            }

            SendEmail(idOrder, idsProducts);
        }

        public IEnumerable<OrdersProductVM> GetAllOrdersProduct()
        {
            var products = orderProductRep.GetAll();
            return mapper.Map<List<OrdersProductVM>>(products);
        }

        public IEnumerable<ProductVM> GetAllProductsForOrder(int idOrder)
        {
            //Eroare deoarace nu stie sa faca skip la mapare la coloana Id
            //var ordersProducts = orderProductRep.GetAll();
            //var idsProducts = ordersProducts.Where(x => x.OrderId == idOrder).Select(x => x.ProductId).ToList();
            var idsProducts = GetProductsIds(idOrder);
            var products = new List<Product>();

            //metoda putin ineficienta, deoarece ajunge sa faca idsProducts.Count call-uri catre baza de date
            //dar a fost cea mai rapida metoda de a ajunge la rezultat, fara a scrie un custom sql si fara a adauga la arhitectura proiectului
            //o alta modalitate rapida de a scrie codul o reprezinta GetAll for products pentru a obtine toate produse si apoi realizarea filtrarii cu id-urile dorite
            //astfel se realizeaza un singur call dar intoarce o cantitate mai mare de date din DB
            foreach(var id in idsProducts)
            {
                products.Add(productRep.GetInstance(id));
            }

            return mapper.Map<List<ProductVM>>(products);
        }

        private void InsertIntoOrderProductTableWithCompositePrimaryKey(OrdersProduct entity)
        {
            string connectionString = configuration.GetConnectionString("AppDbConn");
            SqlConnection connection = new SqlConnection(@connectionString);
            string query = "INSERT INTO OrdersProducts (ProductId,OrderId) VALUES(" + entity.ProductId + "," + entity.OrderId + ")";
            SqlCommand command = new SqlCommand(query, connection);
            try
            {
                connection.Open();
                command.ExecuteNonQuery();
                Console.WriteLine("Records Inserted Successfully");
            }
            catch (SqlException e)
            {
                Console.WriteLine("Error Generated. Details: " + e.ToString());
            }
            finally
            {
                connection.Close();
            }
        }

        private IEnumerable<int> GetProductsIds(int idOrder)
        {
            var productsIds = new List<int>();
            string connectionString = configuration.GetConnectionString("AppDbConn");
            SqlConnection connection = new SqlConnection(@connectionString);
            string query = "SELECT ProductId FROM OrdersProducts WHERE OrderId = " + idOrder; //[OrderIdParameter]";
            SqlCommand command = new SqlCommand(query, connection);
          //  command.Parameters.Add(new SqlParameter("OrderIdParameter", SqlDbType.Int, idOrder));
            try
            {
                connection.Open();
                using (IDataReader myReader = command.ExecuteReader())
                {
                    while (myReader.Read())
                    {
                        productsIds.Add((int)myReader["ProductId"]);
                    }
                }
                Console.WriteLine("Records Query Successfully");
                return productsIds;
            }
            catch (SqlException e)
            {
                Console.WriteLine("Error Generated. Details: " + e.ToString());
            }
            finally 
            {
                connection.Close();
            }

            return productsIds;
        }

        private void SendEmail(int orderId, List<int> idsProducts)
        {
            var order = orderRep.GetInstance(orderId);
            List<Product> products = new List<Product>();
            decimal totalPrice = 0;
            foreach (int idProduct in idsProducts)
            {
                var product = productRep.GetInstance(idProduct);
                totalPrice += product.Price;
                products.Add(product);
            }

            var mailMessage = new MimeMessage();
            mailMessage.From.Add(new MailboxAddress("Firesc Kayus", "firesckayus10@gmail.com"));
            mailMessage.To.Add(new MailboxAddress(order.CustomerName, order.CustomerEmail));
            mailMessage.Subject = "Order from " + order.OrderDate.ToShortDateString();

            StringBuilder productsString = new StringBuilder(Environment.NewLine);

            foreach (var product in products)
            {
                productsString.Append(product.Name + " " + product.Price + Environment.NewLine);
                productsString.Append(product.Description + Environment.NewLine + Environment.NewLine);
            }

            //mailMessage.Body = new TextPart("plain")
            //{
            //    Text = "Hello " + order.CustomerName + "!"
            //};

            // create our message text, just like before (except don't set it as the message.Body)

            //using (var smtpClient = new SmtpClient())
            //{
            //    // smtpClient.Connect("smtp.gmail.com", 587, true);    
            //    smtpClient.Connect("smtp.gmail.com", 465, true);
            //    smtpClient.Authenticate("firesckayus@gmail.com", "tgkmmbyplshxircg");
            //    smtpClient.Send(mailMessage);
            //    smtpClient.Disconnect(true);
            //}


            var body = new TextPart("plain")
            {
                 Text = @"Hey " + order.CustomerName + "," +
                 Environment.NewLine +
                 @"Produsele comandate de catre dumneavoastra sunt in proces de livrare." +
                 Environment.NewLine +

                 productsString.ToString() + Environment.NewLine +

                 @"Pretul total al produselor comandate este " + totalPrice +
                 Environment.NewLine +
                 Environment.NewLine +
                 @"Multumim ca ati comandat de la noi, " +
                 Environment.NewLine +
                 @"Va mai asteptam cu fiecare ocazie sa va luam banii ! " +
                 Environment.NewLine +
                 Environment.NewLine +
                 Environment.NewLine +

                 @" -- Magazinul inimii Firesc Kayus"
            };

            var attachments = new List<MimePart>();

            var productsPath = products.Select(x => x.ImagePath);
            foreach (var path in productsPath)
            {
                var fullPatch = Path.Combine(hostingEnvironment.WebRootPath, path);
                // create an image attachment for the file located at path
                var attachment = new MimePart("image", "gif")
                {
                    Content = new MimeContent(File.OpenRead(fullPatch)),
                    ContentDisposition = new ContentDisposition(ContentDisposition.Attachment),
                    ContentTransferEncoding = ContentEncoding.Base64,
                    FileName = Path.GetFileName(fullPatch)
                };

                attachments.Add(attachment);
            }

            // now create the multipart/mixed container to hold the message text and the
            // image attachment
            var multipart = new Multipart("mixed");
            multipart.Add(body);

            foreach(var attachment in attachments)
            {
                multipart.Add(attachment);
            }


            // now set the multipart/mixed as the message body
            mailMessage.Body = multipart;

            using (var smtpClient = new SmtpClient())
            {
                // smtpClient.Connect("smtp.gmail.com", 587, true);    
                smtpClient.Connect("smtp.gmail.com", 465, true);
                smtpClient.Authenticate("firesckayus@gmail.com", "tgkmmbyplshxircg");
                smtpClient.Send(mailMessage);
                smtpClient.Disconnect(true);
            }



            //var x = new FileStream("test", FileMode.OpenOrCreate);
            //var files = new List<FileStream>();
            //files.Add(x);

            //var builder = new BodyBuilder();
            //builder.HtmlBody = body;

            //foreach (var attachment in files)
            //{
            //    if (attachment.Length > 0)
            //    {
            //        string fileName = Path.GetFileName(attachment.Name);
            //        builder.Attachments.Add(fileName, attachment);
            //    }
            //}
            //message.Body = builder.ToMessageBody();
        }
    }
}
