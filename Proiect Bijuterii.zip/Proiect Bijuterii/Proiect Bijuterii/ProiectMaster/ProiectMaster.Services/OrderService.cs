﻿using AutoMapper;
using ProiectMaster.DataAccess.Interfaces;
using ProiectMaster.Models.DTOs.VM;
using ProiectMaster.Models.Entites;
using ProiectMaster.Models.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProiectMaster.Services
{
    public class OrderService: IOrderService
    {
        private readonly IRepository<Order, int> orderRep;
        private readonly IMapper mapper;

        public OrderService(IRepository<Order, int> orderRep, IMapper mapper)
        {
            this.orderRep = orderRep;
            this.mapper = mapper;
        }

        public void AddOrder(OrderVM dto)
        {
            var entity = mapper.Map<Order>(dto);
            orderRep.Add(entity);
        }

        public int AddWithReturnId(OrderVM dto)
        {
            var entity = mapper.Map<Order>(dto);
            var id = orderRep.AddWithReturnId(entity);
            return id;
        }

        public void DeleteOrder(int id)
        {
            var entity = orderRep.GetInstance(id);
            if (entity == null)
                return;

            orderRep.Delete(entity);
        }

        public IEnumerable<OrderVM> GetAllOrders()
        {
            var orders = orderRep.GetAll();
            var ordersVM = mapper.Map<List<OrderVM>>(orders);
       //     ordersVM.ForEach(x => x.OrderDate = x.OrderDate.Date);
            return ordersVM;
        }

        public OrderVM GetOrder(int id)
        {
            var entity = orderRep.GetInstance(id);
            return mapper.Map<OrderVM>(entity);
        }

        public void UpdateOrder(int id, OrderVM dto)
        {
            var entity = orderRep.GetInstance(id);
            if (entity == null)
                return;

            mapper.Map(dto, entity);
            orderRep.Update(entity);
        }
    }
}
