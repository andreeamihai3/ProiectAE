﻿using ProiectMaster.Models.DTOs.VM;
using ProiectMaster.Models.Entites;
using System.Collections.Generic;

namespace ProiectMaster.Models.Interfaces
{
    public interface IOrdersProductService
    {
        IEnumerable<OrdersProductVM> GetAllOrdersProduct();
        //OrdersProductVM GetOrderProduct(int id);
        void AddOrderProduct(OrdersProductVM dto);

        public void AddOrderProducts(int idOrder, List<int> idsProducts);

        public IEnumerable<ProductVM> GetAllProductsForOrder(int idOrder);
    }
}
