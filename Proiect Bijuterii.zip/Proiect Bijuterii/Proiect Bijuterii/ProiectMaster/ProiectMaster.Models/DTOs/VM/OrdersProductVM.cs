﻿using System.Collections.Generic;

namespace ProiectMaster.Models.DTOs.VM
{
    public class OrdersProductVM
    {
        public int OrderId { get; set; }

        public int ProductId { get; set; }

        public OrdersProductVM(int orderId, int productId)
        {
            this.OrderId = orderId;
            this.ProductId = productId;
        }
    }
}
