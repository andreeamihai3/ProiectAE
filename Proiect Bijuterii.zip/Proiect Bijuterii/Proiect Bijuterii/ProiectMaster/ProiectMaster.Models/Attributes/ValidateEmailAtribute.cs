﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Net.Mail;

namespace ProiectMaster.Models.Attributes
{
    public class ValidateEmailAtribute : ValidationAttribute
    {

        public ValidateEmailAtribute()
        {
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            string email = value as string;
            try
            {
                MailAddress mail = new MailAddress(email);
                return ValidationResult.Success;
            }
            catch (Exception e)
            {
                return new ValidationResult(GetErrorMessage());
            }
        }

        private string GetErrorMessage()
        {
            return $"The email hasn't a correct format !";
        }
    }
}
