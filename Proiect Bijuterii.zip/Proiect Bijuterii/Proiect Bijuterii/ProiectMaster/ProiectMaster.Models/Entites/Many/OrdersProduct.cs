﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ProiectMaster.Models.Entites
{
    public partial class OrdersProduct : IEntity<int>
    {
        public int ProductId { get; set; }
        public int OrderId { get; set; }

        public OrdersProduct(int orderId, int productId)
        {
            this.OrderId = orderId;
            this.ProductId = productId;
        }
        public virtual Order Order { get; set; }
        public virtual Product Product { get; set; }
        public int Id { get => OrderId; set => throw new NotImplementedException(); }
    }
}
